##############################################
#### Analysis of follicular lymphoma data ####
#### April 26, 2018                       ####
##############################################


library(cmprsk)
library(randomForestSRC)
library(aftgee)
library(ranger)


rm(list=ls())
#setwd("/Users/sangbum/Google Drive/My papers/2018/IPW AFT for competing risks/Biostatistics/R/FollicData")

######################
##  Functions
######################

result=function(coef){
  est=coef[,1]
  sd=coef[,2]
  ci1=est-1.96*sd
  ci2=est+1.96*sd	
  out=cbind(est,ci1,ci2)
  round(out,2)
}


weight=function(dt,type='km'){
  if(type=="km"){ 
    km=survfit(Surv(Y,cause==0)~1,dt)
    suv=approx(x=km$time,y=km$surv,xout=dt$Y)$y
  } else if(type=="cox"){
    cox=survfit(coxph(Surv(Y,cause==0)~.,dt))
    suv=approx(x=cox$time,y=cox$surv,xout=dt$Y)$y    
  } else if(type=="rf"){
    rf=ranger(Surv(Y,cause==0)~.,dt)
    msurv=apply(predictions(rf),2,mean)
    suv=approx(x=timepoints(rf),y=msurv,xout=dt$Y)$y
  }
  suv[suv<0.0001]=1
  I(dt$cause==1)/suv
}


Qfunc=function(t,Y,cause,Z,ww,beta){
  c(t(Z)%*%c((Y>t)*ww*(log(Y)-Z%*%beta)))/sum(Y>=t)
}


lmcrr=function(Y,cause,Z,dt,type="km"){
  n = length(Y)
  ww=weight(dt,type)
  beta=lm(log(Y)~Z-1,weights=ww)$coef
  
  A=t(Z)%*%(Z*ww)
  Q=matrix(0,nrow(Z),ncol(Z))
  for(i in 1:n) Q[i,]=Qfunc(Y[i],Y,cause,Z,ww,beta)
  
  Bmat=Z*c(ww*(log(Y)-Z%*%beta))+(cause==0)*Q
  for(i in 1:n){		
    for(j in 1:n){
      if(cause[j]==0)
        Bmat[i,]=Bmat[i,]-(Y[i]>=Y[j])*Q[j,]/sum(Y>=Y[j])
    }
  }
  B=t(Bmat)%*%Bmat
  vv=solve(A)%*%B%*%solve(A)
  se=sqrt(diag(vv))
  data.frame(beta=beta,se=se)
}


cif=function(Y,cause,w){
  Yt=sort(Y); ca=cause[order(Y)]; wt=w[order(Y)]
  Ni=I(ca==1)*wt
  Ybar=apply(1-outer(Yt,Yt,"<")*Ni,2,sum)
  H=cumsum(Ni/Ybar)
  ci=1-exp(-H)
  list(x=Yt,y=ci)
}

####################################
##  Follicular data analysis: Crossed at one-year
####################################
data(follic)
fol<-follic
fol=fol[order(fol$time),]
head(fol)
n=nrow(fol)

age=ifelse(fol$age<60,1,0)
hgb=ifelse(fol$hgb<145,1,0)
stage=ifelse(fol$clinstg==1,1,0)
rct=ifelse(fol$ch=='Y',1,0)
Y=time=pmin(fol$time,30)
cause=stat=fol$status


ci.rct=cuminc(time,stat,rct)
ci.stage=cuminc(time,stat,stage)
ci.age=cuminc(time,stat,age)
ci.hgb=cuminc(time,stat,hgb)


# par(mfrow=c(2,2))
plot(ci.rct$"0 1"$est~ci.rct$"0 1"$time,type='l',
	xlim=c(0,30),ylim=c(0,0.8),
      xlab="Years",ylab="Cumulative incidences")
lines(ci.rct$"1 1"$est~ci.rct$"1 1"$time,lty=2)
lines(ci.rct$"0 2"$est~ci.rct$"0 2"$time,lty=3)
lines(ci.rct$"1 2"$est~ci.rct$"1 2"$time,lty=4)
legend("topleft", c("Nonchemo, Relapse", "Chemo, Relapse",
                    "Nonchemo, Death", "Chemo, Death"),
       lty = 1:4, bty="n")
################
## AFT models
################
dt = data.frame(Y,cause,rct,stage,age,hgb)

lmcrr(Y,cause,cbind(1,stage),dt)

Z=cbind(1,rct,stage,age,hgb)
a1=lmcrr(Y,cause,Z,dt,type="km")
a2=lmcrr(Y,cause,Z,dt,type="cox")
a3=lmcrr(Y,cause,Z,dt,type="rf")

result(a1)
result(a2)
result(a3)


dt2=dt
dt2$ww=weight(dt,"rf")

# plot(lm(log(Y)~rct+stage+age+hgb,weights=ww,subset(dt2,ww>0)))
  




###################
## AFT analysis
###################
z=stage
Z=cbind(1,z)

dt = data.frame(Y, cause)
w=weight(dt)
beta=lm(log(Y)~Z-1,weights=w)$coef

Y1=Y*exp(-cbind(0,z-1)%*%beta)
Y0=Y*exp(-cbind(0,z-0)%*%beta)

ci1=cif(Y1,cause,w)
ci0=cif(Y0,cause,w)

#plot(cuminc(Y,cause,z))
#lines(ci1,col=2)
#lines(ci0,col=4)


###################
## Fine-Gray 
###################
fit=crr(Y,cause,z)
fg1=predict(fit,1)
fg0=predict(fit,0)


plot(ci.stage$"0 1"$est~ci.stage$"0 1"$time,type="s",
     xlab="Years",ylab="Cumulative incidences",ylim=c(0,0.8),xlim=c(0,25),lwd=2,col="gray80")
lines(ci.stage$"1 1"$est~ci.stage$"1 1"$time,type="s",lwd=2,col="gray80")
lines(ci1,type="s",lty=1,lwd=1)
lines(ci0,type="s",lty=1,lwd=1)
lines(fg1,type="s",lty=3,lwd=1)
lines(fg0,type="s",lty=3,lwd=1)
legend(x=16,y=.14,c("Nonparametric","AFT model","Fine-Gray model"),
       col=c("gray80","black","black"),lwd=2,lty=c(1,1,3),bty="n") 




## CS-AFT 
fit1=aftsrr(Surv(time,stat==1)~rct+stage+age+hgb,B=100)
summary(fit1)

fit2=aftsrr(Surv(time,stat==2)~rct+stage+age+hgb,B=100)
summary(fit2)

res1=result(summary(fit1)$coef[[1]])
res2=result(summary(fit2)$coef[[1]])


## CS-Cox 
fit1=coxph(Surv(time,stat==1)~rct+stage+age+hgb)
summary(fit1)
round(summary(fit1)$conf[,-2],2)

fit2=coxph(Surv(time,stat==2)~rct+stage+age+hgb)
summary(fit2)
round(summary(fit2)$conf[,-2],2)


## CR-Cox (Fine-Gray)
cov=cbind(rct,stage,age,hgb)
fit1=crr(time,stat,cov,failcode=1)
summary(fit1)
round(summary(fit1)$conf[,-2],2)

fit2=crr(time,stat,cov,failcode=2)
summary(fit2)
round(summary(fit2)$conf[,-2],2)


## CR-AFT
Z=cbind(1,rct,stage,age,hgb)
n=nrow(Z)
Y=sort(time)
cause=stat[order(time)]
Z=Z[order(time),]


fit1=lmcrr(Y,cause,Z,failcode=1)
fit2=lmcrr(Y,cause,Z,failcode=2)

res1=result(fit1)
res2=result(fit2)

## Checking censoring effect
library(ranger)

cfit = coxph(Surv(Y,cause==0)~rct+stage+age+hgb,dt)
summary(cfit)

summary(coxph(Surv(Y,cause==0)~rct))
summary(coxph(Surv(Y,cause==0)~stage))
summary(coxph(Surv(Y,cause==0)~age))
summary(coxph(Surv(Y,cause==0)~hgb))




