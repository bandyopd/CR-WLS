############################
## Save follic dataset
############################


library(cmprsk)
library(randomForestSRC)

setwd("C:/Users/SChoi6/Documents/Google Drive/My papers/2013/Two-mixture competing risks/FollicData")
fol <- read.table("follic0.txt", sep = ",", header = TRUE)

## creat variables
evcens <- as.numeric(fol$resp == "NR" | fol$relsite != "")
crcens <- as.numeric(fol$resp == "CR" & fol$relsite == "" & fol$stat == 1)
cause <- ifelse(evcens == 1, 1, ifelse(crcens == 1, 2, 0))
table(cause)
stage <- as.numeric(fol$clinstg == 2)
chemo <- as.numeric(fol$ch == "Y")
times1 <- sort(unique(fol$dftime[cause == 1]))


## save datasets
attach(fol)
time<-dftime
dat<-data.frame(cbind(time,cause,stage,chemo,age,hgb))
detach(fol)
write.table(dat,'follic.txt',col.names=TRUE,sep=" ",quote=FALSE)

## analysis by crr
group <- rep(1, nrow(fol))
fit <- cuminc(fol$dftime, cause, group, cencode = 0)
plot(fit)

cov<-cbind(dat$chemo,dat$stage,dat$age<50,dat$hgb<135)
cov<-cbind(dat$stage,dat$chemo)
crr(dat$time,dat$cause,cov,failcode=1)
crr(dat$time,dat$cause,cov,failcode=2)






