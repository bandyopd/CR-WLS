
library(cmprsk)
library(randomForestSRC)
library(aftgee)
library(ranger)


K = function(z, Z, h) dnorm((z - Z)/h)
weight2=function(dt, wt){
   km=survfit(Surv(Y,cause==0)~1,dt, weights = wt)
   suv=approx(x=km$time,y=km$surv,xout=dt$Y)$y
   suv[suv<0.0001]=1
   I(dt$cause==1)/suv
}

data(follic)
fol<-follic
fol=fol[order(fol$time),]
n=nrow(fol)

age=ifelse(fol$age<60,1,0)
hgb=ifelse(fol$hgb<145,1,0)
stage=ifelse(fol$clinstg==1,1,0)
rct=ifelse(fol$ch=='Y',1,0)
Y=time=pmin(fol$time,30)
cause=stat=fol$status

dt = data.frame(Y,cause,rct,stage,age,hgb)

sp = sample(1:n, 170, replace = F)
train = dt[-sp,]
train = train[order(train$Y),]
test = dt[sp,]
test = test[order(test$Y),]
test = test[test$cause!=2,]
testZ = cbind(1,test$rct,test$stage,test$age,test$hgb)
Z=cbind(1,train$rct,train$stage,train$age,train$hgb)

wt = weight2(train, rep(1, nrow(train)))
model_train = lm(log(Y) ~ rct + stage + age + hgb, data = train, weights = wt)

U = predict(model_train, test)

# Localization
set.seed(1)
kern = sapply(U, K, Z = U, h = 1)

b0 = 0
for (i in 1:ncol(kern)) {
   wt = weight2(test, kern[,i])
   mat = U - U[i]
   model_test = lm(log(test$Y) ~ mat, weights = wt)
   b0[i] = model_test$coef[1]
}
cor(log(test$Y[test$cause == 1]), b0[test$cause == 1])
# cor(log(test$Y), b0)


## Correct : consider only cause==1 (Sep 29, 2020)
idd = which(test$cause==1)
nboot = 100
b0_boot = matrix(0, nrow(test), nboot)
for (j in 1:nboot)
{
   for (i in 1:length(U))
   {
      # set.seed(i)
      G = rexp(length(idd)) # Perturbation 
      wt = weight2(test, wt = G*kern[i,]) 
      mat = (U - U[i])
      b0_boot[i,j] = lm(log(test$Y) ~ mat, weights = wt)$coef[1]
   }
}
std = apply(b0_boot, 1, sd)

pivot = 0
for(i in 1:length(b0))
{
   pivot[i] = quantile(abs((b0_boot)[i,] - (b0)[i]) / std[i], 0.975)
}

ind = order(U)
plot(U[ind], b0[ind], type = "n", ylim = c(-2, 2))
polygon(x = c(U[ind], rev(U[ind])),
        y = c((b0 + pivot*std)[ind], rev((b0 - pivot*std)[ind])),
        col = "grey", border = FALSE)
lines(U[ind], b0[ind], col = "blue")
lines(U[ind],
      (b0 + 1.96*std)[ind], lty = 5)
lines(U[ind],
      (b0 - 1.96*std)[ind], lty = 5)



# Entire
kern = rep(1, nrow(test))


b0 = 0
for (i in 1:length(kern)) {
   wt = weight2(test, kern)
   mat = U - U[i]
   model_test = lm(log(test$Y) ~ mat, weights = wt)
   b0[i] = model_test$coef[1]
}
cor(log(test$Y[test$cause == 1]), b0[test$cause == 1])



b0_boot = matrix(0, nrow(test), nboot)
for (j in 1:nboot)
{
   for (i in 1:length(U))
   {
      G = rexp(nrow(test)) # Perturbation 
      wt = weight2(test, wt = G*kern) 
      mat = (U - U[i])
      b0_boot[i,j] = lm(log(test$Y) ~ mat, weights = wt)$coef[1]
   }
}
std = apply(b0_boot, 1, sd)

pivot = 0
for(i in 1:length(b0))
{
   pivot[i] = quantile(abs((b0_boot)[i,] - (b0)[i]) / std[i], 0.975)
}



ind = order(U)
plot(U[ind], b0[ind], type = "n", ylim = c(-2, 2))
polygon(x = c(U[ind], rev(U[ind])),
        y = c((b0 + pivot*std)[ind], rev((b0 - pivot*std)[ind])),
        col = "grey", border = FALSE)
lines(U[ind], b0[ind], col = "blue")
lines(U[ind],
      (b0 + 1.96*std)[ind], lty = 5)
lines(U[ind],
      (b0 - 1.96*std)[ind], lty = 5)

